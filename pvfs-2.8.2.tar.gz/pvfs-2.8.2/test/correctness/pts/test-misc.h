#ifndef TEST_MISC_H
#define TEST_MISC_H

int test_misc(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
