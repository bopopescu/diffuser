#ifndef TEST_NULL_PARAMS_H
#define TEST_NULL_PARAMS_H

int test_null_params(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
