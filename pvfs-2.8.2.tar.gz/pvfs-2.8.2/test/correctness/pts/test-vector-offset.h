#ifndef TEST_VECTOR_OFFSET_H
#define TEST_VECTOR_OFFSET_H

int test_vector_offset(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
