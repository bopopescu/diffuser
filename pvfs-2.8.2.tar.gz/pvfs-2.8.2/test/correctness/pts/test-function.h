#ifndef INCLUDE_TESTFUNCTION_H
#define INCLUDE_TESTFUNCTION_H

int test_function(MPI_Comm *, int, char *buf, void *);

#endif
