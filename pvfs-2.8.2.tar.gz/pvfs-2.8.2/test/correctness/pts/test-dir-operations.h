#ifndef TEST_DIR_OPERATIONS_H
#define TEST_DIR_OPERATIONS_H

int test_dir_operations(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
