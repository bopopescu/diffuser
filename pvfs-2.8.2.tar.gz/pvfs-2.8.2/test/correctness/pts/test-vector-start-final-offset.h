#ifndef TEST_VECTOR_START_FINAL_OFFSET_H
#define TEST_VECTOR_START_FINAL_OFFSET_H

int test_vector_start_final_offset(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
