#ifndef INCLUDE_INVALID_FILES_H
#define INCLUDE_INVALID_FILES_H

int test_invalid_files(MPI_Comm * comm,
		       int rank,
		       char *buf,
		       void *rawparams);

#endif
