#ifndef TEST_NONCONTIG_PATTERN_H
#define TEST_NONCONTIG_PATTERN_H

int test_noncontig_pattern(MPI_Comm *comm, int rank,  char *buf, void *rawparams);

#endif
