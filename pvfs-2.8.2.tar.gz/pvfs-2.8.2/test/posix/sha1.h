#ifndef _SHA1_H
#define _SHA1_H

extern void sha1_file_digest(int fd);

#endif
