# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/<server>:<stripsize>;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="202" HEIGHT="35" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$&lt;server&gt;:&lt;strip size&gt;$">|; 

1;

