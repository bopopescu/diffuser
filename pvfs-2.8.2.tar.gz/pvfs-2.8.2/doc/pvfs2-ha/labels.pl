# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


$key = q/fig:init/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:init-other/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:nodes-aa/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:haresources/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:nodes/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:alias/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:ifconfig-aa/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:haresources-aa/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:haconfig/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:authkeys/;
$external_labels{$key} = "$URL/" . q|pvfs2-ha.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/fig:init/;
$external_latex_labels{$key} = q|7|; 
$noresave{$key} = "$nosave";

$key = q/fig:init-other/;
$external_latex_labels{$key} = q|8|; 
$noresave{$key} = "$nosave";

$key = q/fig:nodes-aa/;
$external_latex_labels{$key} = q|6|; 
$noresave{$key} = "$nosave";

$key = q/fig:haresources/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/fig:nodes/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/fig:alias/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/fig:ifconfig-aa/;
$external_latex_labels{$key} = q|10|; 
$noresave{$key} = "$nosave";

$key = q/fig:haresources-aa/;
$external_latex_labels{$key} = q|9|; 
$noresave{$key} = "$nosave";

$key = q/fig:haconfig/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/fig:authkeys/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

1;

