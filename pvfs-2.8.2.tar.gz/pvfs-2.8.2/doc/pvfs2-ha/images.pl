# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/{figure}scriptsize{preform{<verbatim_mark>verbatim12#preform{scriptsize{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="532" HEIGHT="148" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\begin{figure}\begin{scriptsize}
\begin{verbatim}PVFS2_FS_CONF=/etc/pvfs2/fs.c...
....  ...">|; 

$key = q/includegraphics[scale=0.75]{pvfs2-failover.eps};LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="330" HEIGHT="375" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[scale=0.75]{pvfs2-failover.eps}">|; 

$key = q/{figure}scriptsize{preform{<verbatim_mark>verbatim13#preform{scriptsize{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="532" HEIGHT="148" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\begin{figure}\begin{scriptsize}
\begin{verbatim}PVFS2_FS_CONF=/etc/pvfs2/fs.c...
....  ...">|; 

$key = q/{figure}scriptsize{preform{<verbatim_mark>verbatim9#preform{scriptsize{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="542" HEIGHT="253" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\begin{figure}\begin{scriptsize}
\begin{verbatim}...">|; 

$key = q/includegraphics[scale=0.75]{pvfs2-failover-AA.eps};LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="330" HEIGHT="359" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\includegraphics[scale=0.75]{pvfs2-failover-AA.eps}">|; 

$key = q/{figure}scriptsize{preform{<verbatim_mark>verbatim8#preform{scriptsize{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="550" HEIGHT="420" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\begin{figure}\begin{scriptsize}
\begin{verbatim}...">|; 

$key = q/rightarrow;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$\rightarrow$">|; 

$key = q/{figure}scriptsize{preform{<verbatim_mark>verbatim10#preform{scriptsize{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="541" HEIGHT="144" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\begin{figure}\begin{scriptsize}
\begin{verbatim}...">|; 

$key = q/{figure}scriptsize{preform{<verbatim_mark>verbatim14#preform{scriptsize{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="541" HEIGHT="132" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\begin{figure}\begin{scriptsize}
\begin{verbatim}...">|; 

$key = q/{figure}scriptsize{preform{<verbatim_mark>verbatim11#preform{scriptsize{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="555" HEIGHT="328" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\begin{figure}\begin{scriptsize}
\begin{verbatim}eth0 Link encap:Ethernet HWad...
...:156677942 (149.4 MiB)
Interrupt:29\end{verbatim}
\end{scriptsize}
\end{figure}">|; 

$key = q/{figure}scriptsize{preform{<verbatim_mark>verbatim15#preform{scriptsize{{{{figure};LFS=11;FSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="578" HEIGHT="404" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\begin{figure}\begin{scriptsize}
\begin{verbatim}eth0 Link encap:Ethernet HWad...
...:158334802 (150.9 MiB)
Interrupt:29\end{verbatim}
\end{scriptsize}
\end{figure}">|; 

1;

