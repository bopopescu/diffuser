# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


$key = q/sec:multiple-mounts/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:migration/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:server_100pct_cpu/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:write_slowdown/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nfs_vs_pvfs2/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:version-string/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kernel-version/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:badperf/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rc-kernels/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:why_so_slow/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:supported-architectures/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:nptl_and_mounting/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:df-free-space/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:multiple-disks/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:tuning/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:cron-indexing/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:dir_tuning/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:local_fs/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:open-mx/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:fault-tolerance/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:supported-hw/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:multi-method-badperf/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:howmany-servers/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:undefined_references/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:contributing/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:trove-migration/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:mountintr/;
$external_labels{$key} = "$URL/" . q|pvfs2-faq.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/sec:multiple-mounts/;
$external_latex_labels{$key} = q|3.9|; 
$noresave{$key} = "$nosave";

$key = q/sec:migration/;
$external_latex_labels{$key} = q|9.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:server_100pct_cpu/;
$external_latex_labels{$key} = q|5.2|; 
$noresave{$key} = "$nosave";

$key = q/sec:write_slowdown/;
$external_latex_labels{$key} = q|5.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:nfs_vs_pvfs2/;
$external_latex_labels{$key} = q|6.4|; 
$noresave{$key} = "$nosave";

$key = q/sec:version-string/;
$external_latex_labels{$key} = q|1.5|; 
$noresave{$key} = "$nosave";

$key = q/sec:kernel-version/;
$external_latex_labels{$key} = q|2.4|; 
$noresave{$key} = "$nosave";

$key = q/sec:badperf/;
$external_latex_labels{$key} = q|6.2|; 
$noresave{$key} = "$nosave";

$key = q/sec:rc-kernels/;
$external_latex_labels{$key} = q|5.18|; 
$noresave{$key} = "$nosave";

$key = q/sec:why_so_slow/;
$external_latex_labels{$key} = q|6.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:supported-architectures/;
$external_latex_labels{$key} = q|2.2|; 
$noresave{$key} = "$nosave";

$key = q/sec:nptl_and_mounting/;
$external_latex_labels{$key} = q|5.8|; 
$noresave{$key} = "$nosave";

$key = q/sec:df-free-space/;
$external_latex_labels{$key} = q|9.4|; 
$noresave{$key} = "$nosave";

$key = q/sec:multiple-disks/;
$external_latex_labels{$key} = q|3.2|; 
$noresave{$key} = "$nosave";

$key = q/sec:tuning/;
$external_latex_labels{$key} = q|6.7|; 
$noresave{$key} = "$nosave";

$key = q/sec:cron-indexing/;
$external_latex_labels{$key} = q|5.5|; 
$noresave{$key} = "$nosave";

$key = q/sec:dir_tuning/;
$external_latex_labels{$key} = q|6.6|; 
$noresave{$key} = "$nosave";

$key = q/sec:local_fs/;
$external_latex_labels{$key} = q|6.5|; 
$noresave{$key} = "$nosave";

$key = q/sec:open-mx/;
$external_latex_labels{$key} = q|5.19|; 
$noresave{$key} = "$nosave";

$key = q/sec:fault-tolerance/;
$external_latex_labels{$key} = q|7|; 
$noresave{$key} = "$nosave";

$key = q/sec:supported-hw/;
$external_latex_labels{$key} = q|2.5|; 
$noresave{$key} = "$nosave";

$key = q/sec:multi-method-badperf/;
$external_latex_labels{$key} = q|6.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:howmany-servers/;
$external_latex_labels{$key} = q|3.6|; 
$noresave{$key} = "$nosave";

$key = q/sec:undefined_references/;
$external_latex_labels{$key} = q|5.15|; 
$noresave{$key} = "$nosave";

$key = q/sec:contributing/;
$external_latex_labels{$key} = q|11.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:trove-migration/;
$external_latex_labels{$key} = q|5.17|; 
$noresave{$key} = "$nosave";

$key = q/sec:mountintr/;
$external_latex_labels{$key} = q|9.6|; 
$noresave{$key} = "$nosave";

1;

