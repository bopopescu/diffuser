# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/sec:gcc/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:proto/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:static/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pvfs-naming/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:editors/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:gdb/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:gpl/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:indent/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:comments/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pvfs-copyright/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pvfs-comments/;
$ref_files{$key} = "$dir".q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

1;

