# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


$key = q/sec:gcc/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:proto/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:static/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pvfs-naming/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:editors/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:gdb/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:gpl/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:indent/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:comments/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pvfs-copyright/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:pvfs-comments/;
$external_labels{$key} = "$URL/" . q|developer-guidelines.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/sec:gcc/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/sec:proto/;
$external_latex_labels{$key} = q|9.2.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:static/;
$external_latex_labels{$key} = q|9.2.4|; 
$noresave{$key} = "$nosave";

$key = q/sec:pvfs-naming/;
$external_latex_labels{$key} = q|10.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:editors/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/sec:gdb/;
$external_latex_labels{$key} = q|6|; 
$noresave{$key} = "$nosave";

$key = q/sec:gpl/;
$external_latex_labels{$key} = q|9.1.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:indent/;
$external_latex_labels{$key} = q|9.1.5|; 
$noresave{$key} = "$nosave";

$key = q/sec:comments/;
$external_latex_labels{$key} = q|9.1.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:pvfs-copyright/;
$external_latex_labels{$key} = q|10.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:pvfs-comments/;
$external_latex_labels{$key} = q|10.2|; 
$noresave{$key} = "$nosave";

1;

