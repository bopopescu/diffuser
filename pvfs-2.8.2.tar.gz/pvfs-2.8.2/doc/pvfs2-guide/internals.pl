# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/sec:apis/;
$ref_files{$key} = "$dir".q|pvfs2-guide.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:basics/;
$ref_files{$key} = "$dir".q|pvfs2-guide.html|; 
$noresave{$key} = "$nosave";

1;

