# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/O(1);MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="40" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$O(1)$">|; 

1;

