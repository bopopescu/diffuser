# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/null1L/;
$ref_files{$key} = "$dir".q|SystemInterfaceTesting.html|; 
$noresave{$key} = "$nosave";

$key = q/setupL/;
$ref_files{$key} = "$dir".q|SystemInterfaceTesting.html|; 
$noresave{$key} = "$nosave";

1;

