# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/includegraphics[scale=0.4]{pvfs2-vfs.eps};LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="372" HEIGHT="199" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[scale=0.4]{pvfs2-vfs.eps}">|; 

$key = q/includegraphics[scale=0.4]{core-sm.eps};LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="328" HEIGHT="518" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[scale=0.4]{core-sm.eps}">|; 

1;

