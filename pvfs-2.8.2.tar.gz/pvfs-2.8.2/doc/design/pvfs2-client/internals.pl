# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/figure:generic-sm/;
$ref_files{$key} = "$dir".q|pvfs2-client.html|; 
$noresave{$key} = "$nosave";

$key = q/figure:arch/;
$ref_files{$key} = "$dir".q|pvfs2-client.html|; 
$noresave{$key} = "$nosave";

1;

