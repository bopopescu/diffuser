# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/includegraphics[scale=1.0]{figs_atoc.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="480" HEIGHT="570" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[scale=1.0]{figs_atoc.eps}">|; 

$key = q/includegraphics[scale=1.0]{figs_dtoe.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="480" HEIGHT="343" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[scale=1.0]{figs_dtoe.eps}">|; 

1;

