# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/includegraphics[scale=0.4]{bmi-arch-color.eps};LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="324" HEIGHT="330" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[scale=0.4]{bmi-arch-color.eps}">|; 

1;

