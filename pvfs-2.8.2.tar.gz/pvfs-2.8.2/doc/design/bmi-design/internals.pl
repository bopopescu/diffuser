# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/sec:unexp/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/method-control-intro/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:user/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:high/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:short/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:arch/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:support/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:bmi-arch/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:methguide/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:ref/;
$ref_files{$key} = "$dir".q|bmi-design.html|; 
$noresave{$key} = "$nosave";

1;

