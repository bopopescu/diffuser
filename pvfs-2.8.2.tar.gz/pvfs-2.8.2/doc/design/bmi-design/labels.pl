# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


$key = q/sec:unexp/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/method-control-intro/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:user/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:high/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:short/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:arch/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:support/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:bmi-arch/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:methguide/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:ref/;
$external_labels{$key} = "$URL/" . q|bmi-design.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/sec:unexp/;
$external_latex_labels{$key} = q|5.2|; 
$noresave{$key} = "$nosave";

$key = q/method-control-intro/;
$external_latex_labels{$key} = q|4.4.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:user/;
$external_latex_labels{$key} = q|6|; 
$noresave{$key} = "$nosave";

$key = q/sec:high/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/sec:short/;
$external_latex_labels{$key} = q|5.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:arch/;
$external_latex_labels{$key} = q|4.4|; 
$noresave{$key} = "$nosave";

$key = q/sec:support/;
$external_latex_labels{$key} = q|7.3|; 
$noresave{$key} = "$nosave";

$key = q/fig:bmi-arch/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/sec:methguide/;
$external_latex_labels{$key} = q|7|; 
$noresave{$key} = "$nosave";

$key = q/sec:ref/;
$external_latex_labels{$key} = q|8|; 
$noresave{$key} = "$nosave";

1;

