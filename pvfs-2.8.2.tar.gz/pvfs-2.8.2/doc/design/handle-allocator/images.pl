# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/H;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="$H$">|; 

$key = q/N_{purg};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="45" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="$N_{purg}$">|; 

$key = q/{displaymath}F_{purg}=N_{purg}slashN_{tot}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="135" HEIGHT="29" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\begin{displaymath}
F_{purg} = N_{purg} / N_{tot}
\end{displaymath}">|; 

$key = q/T_{f};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="22" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="$T_{f}$">|; 

$key = q/{displaymath}F_{purg}=T_{f}slash(T_{r}*N_{tot}){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="156" HEIGHT="29" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\begin{displaymath}
F_{purg} = T_{f} / (T_{r} * N_{tot})
\end{displaymath}">|; 

$key = q/N_{tot};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="34" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="$N_{tot}$">|; 

$key = q/{displaymath}N_{purg}=T_{f}slashT_{r}{displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="102" HEIGHT="29" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\begin{displaymath}
N_{purg} = T_{f} / T_{r}
\end{displaymath}">|; 

$key = q/N;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="19" HEIGHT="14" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="$N$">|; 

$key = q/T_{r};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="21" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="$T_{r}$">|; 

$key = q/first>last;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="88" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$ first &gt; last $">|; 

1;

