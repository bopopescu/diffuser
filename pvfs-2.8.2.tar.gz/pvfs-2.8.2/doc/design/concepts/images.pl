# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/includegraphics[scale=0.25]{interface-model.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="281" HEIGHT="209" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[scale=0.25]{interface-model.eps}">|; 

$key = q/includegraphics[scale=0.5]{setmeta-protocol.eps};AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="594" HEIGHT="244" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\includegraphics[scale=0.5]{setmeta-protocol.eps}">|; 

1;

