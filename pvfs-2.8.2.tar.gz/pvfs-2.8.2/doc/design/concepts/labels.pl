# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


$key = q/fig:interface-model/;
$external_labels{$key} = "$URL/" . q|concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:setmeta-protocol/;
$external_labels{$key} = "$URL/" . q|concepts.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/fig:interface-model/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/fig:setmeta-protocol/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

1;

