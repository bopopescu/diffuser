# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/fig:interface-model/;
$ref_files{$key} = "$dir".q|concepts.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:setmeta-protocol/;
$ref_files{$key} = "$dir".q|concepts.html|; 
$noresave{$key} = "$nosave";

1;

