# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/includegraphics[scale=0.6]{flow-arch.eps};LFS=12;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="707" HEIGHT="422" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\includegraphics[scale=0.6]{flow-arch.eps}">|; 

1;

