# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/sec:arch/;
$ref_files{$key} = "$dir".q|flow-design.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:flow-arch/;
$ref_files{$key} = "$dir".q|flow-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow-desc/;
$ref_files{$key} = "$dir".q|flow-design.html|; 
$noresave{$key} = "$nosave";

1;

