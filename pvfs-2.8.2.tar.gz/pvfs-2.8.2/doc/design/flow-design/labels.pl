# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


$key = q/sec:arch/;
$external_labels{$key} = "$URL/" . q|flow-design.html|; 
$noresave{$key} = "$nosave";

$key = q/fig:flow-arch/;
$external_labels{$key} = "$URL/" . q|flow-design.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow-desc/;
$external_labels{$key} = "$URL/" . q|flow-design.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/sec:arch/;
$external_latex_labels{$key} = q|3.2|; 
$noresave{$key} = "$nosave";

$key = q/fig:flow-arch/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/sec:flow-desc/;
$external_latex_labels{$key} = q|4.1|; 
$noresave{$key} = "$nosave";

1;

