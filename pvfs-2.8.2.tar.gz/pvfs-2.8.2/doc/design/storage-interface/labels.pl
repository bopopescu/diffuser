# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


$key = q/table:storage_errors/;
$external_labels{$key} = "$URL/" . q|storage-interface.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/table:storage_errors/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

1;

