# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/table:storage_errors/;
$ref_files{$key} = "$dir".q|storage-interface.html|; 
$noresave{$key} = "$nosave";

1;

