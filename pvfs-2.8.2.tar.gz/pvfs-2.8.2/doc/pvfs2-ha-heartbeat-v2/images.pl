# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/lceil((Nslash2)-1)rceil;MSF=1.6;LFS=11;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="109" HEIGHT="36" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="$\lceil ((N/2)-1) \rceil$">|; 

1;

