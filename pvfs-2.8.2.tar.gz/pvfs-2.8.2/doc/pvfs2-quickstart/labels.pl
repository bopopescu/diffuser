# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


$key = q/sec:howto/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vfs24-configure/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:single/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:server-config/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kernel-check/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:testing/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vfs-configure/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rc/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vfs-test/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:client/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kernel-interface/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:cluster/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:romio/;
$external_labels{$key} = "$URL/" . q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/sec:howto/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/sec:vfs24-configure/;
$external_latex_labels{$key} = q|5.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:single/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/sec:server-config/;
$external_latex_labels{$key} = q|4.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:kernel-check/;
$external_latex_labels{$key} = q|5.1|; 
$noresave{$key} = "$nosave";

$key = q/subsec:testing/;
$external_latex_labels{$key} = q|3.4|; 
$noresave{$key} = "$nosave";

$key = q/sec:vfs-configure/;
$external_latex_labels{$key} = q|5.2|; 
$noresave{$key} = "$nosave";

$key = q/sec:rc/;
$external_latex_labels{$key} = q|3.2.1|; 
$noresave{$key} = "$nosave";

$key = q/sec:vfs-test/;
$external_latex_labels{$key} = q|5.4|; 
$noresave{$key} = "$nosave";

$key = q/subsec:client/;
$external_latex_labels{$key} = q|3.3|; 
$noresave{$key} = "$nosave";

$key = q/sec:kernel-interface/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/sec:cluster/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/sec:romio/;
$external_latex_labels{$key} = q|C|; 
$noresave{$key} = "$nosave";

1;

