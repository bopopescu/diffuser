# LaTeX2HTML 2002-2-1 (1.71)
# Associate internals original text with physical files.


$key = q/sec:howto/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vfs24-configure/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:single/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:server-config/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kernel-check/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:testing/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vfs-configure/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:rc/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:vfs-test/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/subsec:client/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:kernel-interface/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:cluster/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

$key = q/sec:romio/;
$ref_files{$key} = "$dir".q|pvfs2-quickstart.html|; 
$noresave{$key} = "$nosave";

1;

